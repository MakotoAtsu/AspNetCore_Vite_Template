import { ServerOptions } from 'vite'

export default {
https: { pfx: 'devcert.pfx', passphrase: 'd9e1e40b94e945f5bf40c49bb0c29684' }
}

